import java.util.Scanner;

public class PUCV extends Libro{
    private String escuela;

    public PUCV(int id,String titulo,String autor,int precio,String escuela) {
        super(id,titulo,autor,precio);
        this.escuela = escuela;
    }
    public PUCV(){
        super(0,"","",0);
        escuela = null;
    }

    public String getEscuela() {
        return escuela;
    }
    public void setEscuela(String escuela) {
        this.escuela = escuela;
    }

    public PUCV crearLibro(){
        int id;
        String title;
        String Autor;
        int precio;
        String escuela;
        Scanner sc= new Scanner(System.in);


        System.out.println("Ingrese id del libro: ");
        id= sc.nextInt();
        sc.nextLine();
        System.out.println("Ingrese titulo del libro: ");
        title= sc.nextLine();
        System.out.println("Ingrese autor del libro: ");
        Autor= sc.nextLine();
        System.out.println("Ingrese precio del libro: ");
        precio= sc.nextInt();
        sc.nextLine();
        System.out.println("Ingrese escuela: ");
        escuela= sc.nextLine();
        PUCV pc= new PUCV(id,title,Autor,precio,escuela);
        return pc;
    }
    public void mostrarLibro(){
        super.mostrarLibro();
        System.out.println("Escuela encargada: "+getEscuela());
    }


}
