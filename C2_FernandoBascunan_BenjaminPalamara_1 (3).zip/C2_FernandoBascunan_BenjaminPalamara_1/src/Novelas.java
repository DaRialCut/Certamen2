import java.util.Scanner;

public class Novelas extends Libro {
    private String tipoNovela;
    public Novelas(){
        super(0,"","",0);
    }

    public Novelas(int idLibro, String titulo, String autor, int precio, String tipoNovela) {
        super(idLibro, titulo, autor, precio);
        this.tipoNovela = tipoNovela;
    }

    public String getTipoNovela() {
        return tipoNovela;
    }

    public void setTipoNovela(String tipoNovela) {
        this.tipoNovela = tipoNovela;
    }

    public Novelas crearLibro(){
        int id;
        String title;
        String Autor;
        int precio;
        String tipoNovela;
        Scanner sc= new Scanner(System.in);


        System.out.println("Ingrese id del libro: ");
        id= sc.nextInt();
        sc.nextLine();
        System.out.println("Ingrese titulo del libro: ");
        title= sc.nextLine();
        System.out.println("Ingrese autor del libro: ");
        Autor= sc.nextLine();
        System.out.println("Ingrese precio del libro: ");
        precio= sc.nextInt();
        sc.nextLine();
        System.out.println("Ingrese escuela: ");
        tipoNovela= sc.nextLine();
        Novelas pc= new Novelas(id,title,Autor,precio,tipoNovela);
        return pc;
    }
    public void mostrarLibro(){
        super.mostrarLibro();
        System.out.println("Tipo de novela: "+getTipoNovela());
    }
}

