import java.util.Scanner;

public class Main {
        static void menuAcademico(){
            System.out.println("1. Agregar Academico\n 2.Buscar Academico");
        }
        static void menuAcademico(int opcion){
            Biblioteca b =new Biblioteca();
            Academico a= new Academico();
            Scanner sc =new Scanner(System.in);
            switch (opcion){
                case 1:
                    b.agregarAcademico();
                    break;
                case 2:
                    int buscar;
                    System.out.println("Ingresa el id Buscado: ");
                    buscar= sc.nextInt();
                    if(b.buscarAcademico(buscar)== null){
                        System.out.println("Libro no encontrado");
                    }
                    else{b.buscarAcademico(buscar).mostrarLibro();}
                    break;
            }
        }
        static void menuNovela(){
            System.out.println("1. Agregar Novela\n 2.Buscar Novela");
        }
        static void menuNovela(int choice){
            Biblioteca b =new Biblioteca();
            Novelas n= new Novelas();
            Scanner sc =new Scanner(System.in);
            switch (choice){
                case 1:
                    b.agregarNovela();
                    break;
                case 2:
                    int buscar;
                    System.out.println("Ingresa el id Buscado: ");
                    buscar= sc.nextInt();
                    if(b.buscarNovela(buscar)==null){
                        System.out.println("Libro no encontrado");
                    }
                    else{
                        b.buscarNovela(buscar).mostrarLibro();
                    }
                    break;
            }
        }
        static void menuPUCV(){
            System.out.println("1. Agregar libro PUCV\n 2.Buscar libro PUCV");
        }
        static void menuPUCV(int choice){
            Biblioteca b =new Biblioteca();
            PUCV p= new PUCV();
            Scanner sc =new Scanner(System.in);
            switch (choice){
                case 1:
                    b.agregarPUCV();
                    break;
                case 2:
                    int buscar;
                    System.out.println("Ingresa el id Buscado: ");
                    buscar= sc.nextInt();
                    if(b.buscarPUCV(buscar)==null){
                        System.out.println("Libro no encontrado");
                    }
                    else{b.buscarPUCV(buscar).mostrarLibro();}
                    break;
            }
        }
        static void mainMenu(){
            int opcion;
            Scanner scanner = new Scanner(System.in);
            Biblioteca b = new Biblioteca();



            System.out.println("Bienvenido.\n");


            System.out.println("Que tipo de libro desea Agregar/Buscar/Mostrar?\n");
            System.out.println("1- Libro academico");
            System.out.println("2- Novela");
            System.out.println("3- Libro de texto PUCV\n");
            System.out.print("Ingrese una opcion: ");
            opcion = scanner.nextInt();

            switch(opcion){
                case 1:
                    int choice;
                    menuAcademico();
                    choice= scanner.nextInt();
                    scanner.nextLine();
                    menuAcademico(choice);
                    mainMenu();
                    break;
                case 2:
                    int choice2;
                    menuNovela();
                    choice2 = scanner.nextInt();
                    scanner.nextLine();
                    menuNovela(choice2);
                    mainMenu();
                    break;
                case 3:
                    int choice3;
                    menuPUCV();
                    choice3 = scanner.nextInt();
                    scanner.nextLine();
                    menuPUCV(choice3);
                    mainMenu();
                    break;
                default:
                    System.out.println("Error, opcion no valida");
                    mainMenu();
                    break;

            }
        }

    public static void main(String[] args) {
        mainMenu();

    }
}