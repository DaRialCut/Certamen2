import java.util.Scanner;

public class Academico extends Libro{

    private String ramo;
    public Academico(){
        super(0,"","",0);
    }

    public Academico(int idLibro, String titulo, String autor, int precio, String ramo){
        super(idLibro,titulo,autor,precio);
        this.ramo = ramo;
    }

    public String getRamo() {
        return ramo;
    }

    public void setRamo(String ramo) {
        this.ramo = ramo;
    }

    public Academico crearLibro(){
        int id;
        String title;
        String Autor;
        int precio;
        String tipoNovela;
        Scanner sc= new Scanner(System.in);


        System.out.println("Ingrese id del libro: ");
        id= sc.nextInt();
        sc.nextLine();
        System.out.println("Ingrese titulo del libro: ");
        title= sc.nextLine();
        System.out.println("Ingrese autor del libro: ");
        Autor= sc.nextLine();
        System.out.println("Ingrese precio del libro: ");
        precio= sc.nextInt();
        sc.nextLine();
        System.out.println("Ingrese tipo del libro: ");
        ramo= sc.nextLine();
        Academico pc= new Academico(id,title,Autor,precio,ramo);
        return pc;
    }

    public void mostrarLibro(){
        super.mostrarLibro();
        System.out.println("Tipo de Libro Academico: "+getRamo());
    }
}
