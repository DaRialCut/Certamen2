import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class Biblioteca {
    private ArrayList<Novelas> listaNovelas = new ArrayList<>();
    private ArrayList<Academico> listaAcademicos = new ArrayList<>();
    private ArrayList<PUCV> listaPUCV = new ArrayList<>();

     public Biblioteca(){
     }

    public ArrayList<Novelas> getListaNovelas() {
        return listaNovelas;
    }

    public void setListaNovelas(ArrayList<Novelas> listaNovelas) {
        this.listaNovelas = listaNovelas;
    }

    public ArrayList<Academico> getListaAcademicos() {
        return listaAcademicos;
    }

    public void setListaAcademicos(ArrayList<Academico> listaAcademicos) {
        this.listaAcademicos = listaAcademicos;
    }

    public ArrayList<PUCV> getListaPUCV(){
         return listaPUCV;
    }
    public void setListaPUCV(ArrayList<PUCV> listaPUCV) {
        this.listaPUCV = listaPUCV;
    }


    public void agregarAcademico(){
        int id;
        String title;
        String Autor;
        int precio;
        String ramo;
        Scanner sc= new Scanner(System.in);


        System.out.println("Ingrese id del libro: ");
        id= sc.nextInt();
        sc.nextLine();
        System.out.println("Ingrese titulo del libro: ");
        title= sc.nextLine();
        System.out.println("Ingrese autor del libro: ");
        Autor= sc.nextLine();
        System.out.println("Ingrese precio del libro: ");
        precio= sc.nextInt();
        sc.nextLine();
        System.out.println("Ingrese tipo del libro: ");
        ramo= sc.nextLine();
        Academico pc= new Academico(id,title,Autor,precio,ramo);
        pc.mostrarLibro();
        getListaAcademicos().add(pc);
    }
    public void agregarNovela(){
        int id;
        String title;
        String Autor;
        int precio;
        String tipoNovela;
        Scanner sc= new Scanner(System.in);


        System.out.println("Ingrese id del libro: ");
        id= sc.nextInt();
        sc.nextLine();
        System.out.println("Ingrese titulo del libro: ");
        title= sc.nextLine();
        System.out.println("Ingrese autor del libro: ");
        Autor= sc.nextLine();
        System.out.println("Ingrese precio del libro: ");
        precio= sc.nextInt();
        sc.nextLine();
        System.out.println("Ingrese escuela: ");
        tipoNovela= sc.nextLine();
        Novelas pc= new Novelas(id,title,Autor,precio,tipoNovela);
        getListaNovelas().add(pc);
    }
    public void agregarPUCV(){
        int id;
        String title;
        String Autor;
        int precio;
        String escuela;
        Scanner sc= new Scanner(System.in);


        System.out.println("Ingrese id del libro: ");
        id= sc.nextInt();
        sc.nextLine();
        System.out.println("Ingrese titulo del libro: ");
        title= sc.nextLine();
        System.out.println("Ingrese autor del libro: ");
        Autor= sc.nextLine();
        System.out.println("Ingrese precio del libro: ");
        precio= sc.nextInt();
        sc.nextLine();
        System.out.println("Ingrese escuela: ");
        escuela= sc.nextLine();
        PUCV pc= new PUCV(id,title,Autor,precio,escuela);

        getListaPUCV().add(pc);
    }

    public Academico buscarAcademico(int id){
         for(Academico ac : getListaAcademicos()){
             if(ac.getIdLibro()==id){
                 return ac;
             }
         }
         return null;
    }
    public Novelas buscarNovela(int id){
        for(Novelas nv : getListaNovelas()){
            if(nv.getIdLibro()==id){
                return nv;
            }
        }
        return null;
    }
    public PUCV buscarPUCV(int id){
        for(PUCV p : getListaPUCV()){
            if(p.getIdLibro()==id){
                return p;
            }
        }
        return null;
    }



}
